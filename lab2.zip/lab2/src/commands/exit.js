module.exports = (state, params) => {
    console.log('Bye-bye');
    process.exit();
}
