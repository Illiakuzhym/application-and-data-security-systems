const robin = require('./generator/robin');
const bignum = require('./bignum/bignum');
const FEAL = require('./feal/feal');
const fs = require('fs');

const minvalue = bignum().minForDischarge(64);
const maxvalue = bignum().maxForDischarge(64);

const closedKey = robin(minvalue, maxvalue);
const publicKey = robin(minvalue, maxvalue);

console.log(closedKey);
console.log(publicKey);

const cipher = new FEAL(publicKey);

const input = fs.readFileSync(__dirname + '/input.txt');
const encrypted = cipher.encrypt(closedKey, input);

fs.writeFileSync(__dirname + '/close.txt', encrypted);
const closed = fs.readFileSync(__dirname + '/close.txt');

const decrypted = cipher.decrypt(closed);
fs.writeFileSync(__dirname + '/open.txt', decrypted);
