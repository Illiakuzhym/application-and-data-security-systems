# Lab 4

Install [nodejs](https://nodejs.org/uk/download/)

Start program `npm start`

