// const robin = require('./generator/robin');
// const bignum = require('./bignum/bignum');

// const minvalue = bignum().minForDischarge(64);
// const maxvalue = bignum().maxForDischarge(64);

// const Num1 = robin(minvalue, maxvalue);
// const Num2 = robin(minvalue, maxvalue);

// console.log('First prime: ' + Num1);
// console.log('Second prime: ' + Num2);

console.log('First prime: ' + '7402100000000000000000000000000000000000000000000000000000005478');
console.log('Second prime: ' + '1352000000000000000000000000000000000000000000000000000000089509');