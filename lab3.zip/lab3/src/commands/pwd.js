module.exports = (state, params) => {
    console.log(state.currentDir)
};
